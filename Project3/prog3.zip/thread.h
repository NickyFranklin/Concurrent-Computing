#ifndef THREADCLASS_H
#define THREADCLASS_H
#include "ThreadClass.h"
#endif
//--------------------------------------------------
//Name: Nicky Franklin         User Id: nafrankl
//Due Date: 10/16/23
//Program Assignment 3
//File Name: thread.h
//Program Purpose:
//Provide class definitions for the thread.cpp file
//----------------------------------------------------
class PreFix : public Thread {
 public:
  PreFix();
  void setPreFix(int, int*, int, int);
  ~PreFix();
  void print();
  int k;

 private:
  void ThreadFunc();
  void log();
  int exponent();
  int n;
  int *x;
  int i;
  int j;
};
